import mysql.connector
from mysql.connector import Error
from werkzeug.security import generate_password_hash, check_password_hash
from mysql.connector.errors import IntegrityError

def get_db_connection():
    """建立並返回數據庫連接"""
    try:
        connection = mysql.connector.connect(
            user="root",
            password="",
            host="localhost",
            port=3306,
            database="delivery_platform"
        )
        if connection.is_connected():
            return connection
    except Error as e:
        print(f"數據庫連接失敗: {e}")
        raise


def execute_query(query, params=None, fetchone=False, fetchall=False):
    """輔助函數，用於執行數據庫查詢"""
    
    conn = None
    cursor = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute(query, params or ())

        # 消耗所有未讀取的結果集
        while cursor.nextset():
            cursor.fetchall()  # 強制消耗所有結果集

        # 根據查詢類型來處理結果集
        result = None
        if fetchone:
            result = cursor.fetchone()
        elif fetchall:
            result = cursor.fetchall()

        # 如果是更新類查詢，則提交
        if not fetchone and not fetchall:
            conn.commit()

        return result
    except Error as e:
        print(f"執行查詢時發生錯誤: {e}")
        raise
    finally:
        # 確保游標和連接都被正確關閉
        if cursor:
            cursor.close()
        if conn:
            try:
                if conn.is_connected():
                    conn.close()
            except Error as e:
                print(f"關閉連接時發生錯誤: {e}")


# 外送員管理功能

def register_rider(user_id, password, name=None):
    """註冊新外送員，支援儲存名稱"""
    try:
        hashed_password = generate_password_hash(password)
        query = "INSERT INTO riders (user_id, password, name) VALUES (%s, %s, %s)"
        execute_query(query, (user_id, hashed_password, name))
        return True
    except mysql.connector.IntegrityError as e:
        print(f"註冊失敗: {e}")
        return False

def login_rider(user_id, password):
    """驗證外送員登錄"""
    query = "SELECT * FROM riders WHERE user_id = %s"
    rider = execute_query(query, (user_id,), fetchone=True)
    if rider and check_password_hash(rider['password'], password):
        return True
    return False


# 訂單管理功能

def get_available_orders(status=None, rider_id=None):
    """
    獲取訂單列表
    - status: 訂單的狀態
    - rider_id: 指定外送員的訂單
    """
    query = "SELECT * FROM orders WHERE 1=1"
    params = []
    
    if status:
        query += " AND status = %s"
        params.append(status)
    if rider_id:
        query += " AND rider_id = %s"
        params.append(rider_id)
    
    query += " ORDER BY id ASC"
    return execute_query(query, params=params, fetchall=True)
        
def accept_order(order_id, rider_id):
    """外送員接單，更新訂單的 rider_id 和狀態"""
    try:
        # 打印調試信息，確保傳入的 rider_id 正確
        print(f"正在檢查外送員的ID: {rider_id}")
        
        # 檢查 rider_id 是否存在於 riders 表中，應該根據 user_id 查詢
        check_rider_query = "SELECT id FROM riders WHERE user_id = %s"
        rider_exists = execute_query(check_rider_query, (rider_id,))
        
        # 打印查詢結果，檢查外送員是否存在
        print(f"查詢結果: {rider_exists}")
        
        if not rider_exists:
            print(f"錯誤: 外送員 {rider_id} 不存在")
            return False

        query = """
            UPDATE orders
            SET rider_id = %s, status = 'In Transit'
            WHERE id = %s AND rider_id IS NULL
        """
        affected_rows = execute_query(query, (rider_id, order_id))
        
        # 打印 affected_rows，確認是否成功更新訂單
        print(f"受影響的行數: {affected_rows}")
        
        if affected_rows > 0:
            return True
        else:
            print(f"錯誤: 訂單 {order_id} 無法被外送員 {rider_id} 接單，可能已經被其他人接單")
            return False
    except IntegrityError as e:
        print(f"接單失敗: {e}")
        return False


    
def pickup_order(order_id, rider_id):
    """標記訂單已取餐"""
    query = "UPDATE orders SET status = 'Picked Up' WHERE id = %s AND rider_id = %s"
    execute_query(query, (order_id, rider_id))
    return True

def complete_order(order_id, rider_id):
    """標記訂單已完成"""
    query = """
        UPDATE orders 
        SET status = 'Completed', delivered_at = NOW() 
        WHERE id = %s AND rider_id = %s
    """
    execute_query(query, (order_id, rider_id))
    return True
