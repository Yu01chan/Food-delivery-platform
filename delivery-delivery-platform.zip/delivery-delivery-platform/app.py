from flask import Flask, render_template, request, redirect, url_for, flash, session
from functools import wraps
from mysql.connector.errors import IntegrityError
from dbutils import (
    register_rider,
    login_rider,
    get_available_orders,
    accept_order,
    pickup_order,
    complete_order
)

app = Flask(__name__)
app.secret_key = 'your_password'

# 裝飾器：確保使用者已登入
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'rider_id' not in session:
            flash("請先登錄")
            return redirect(url_for('rider_login'))
        return f(*args, **kwargs)
    return decorated_function

# 註冊頁面
@app.route("/rider/register", methods=["GET", "POST"])
def rider_register():
    if request.method == "POST":
        user_id = request.form['user_id']
        password = request.form['password']
        if register_rider(user_id, password):
            flash("註冊成功！請登錄")
            return redirect(url_for('rider_login'))
        else:
            flash("註冊失敗，賬號可能已存在")
    return render_template("rider_register.html")

# 登錄頁面
@app.route("/rider/login", methods=["GET", "POST"])
def rider_login():
    if request.method == "POST":
        user_id = request.form['user_id']
        password = request.form['password']
        if login_rider(user_id, password):
            session['rider_id'] = user_id
            return redirect(url_for('rider_dashboard'))
        else:
            flash("登錄失敗，請檢查您的賬號信息")
    return render_template("rider_login.html")

# 儀表板頁面
@app.route("/rider/dashboard")
@login_required
def rider_dashboard():
    active_orders = get_available_orders(status="active", rider_id=session['rider_id'])
    return render_template("rider_dashboard.html", active_orders=active_orders)

# 接單頁面
@app.route("/rider/orders")
@login_required
def rider_orders():
    available_orders = get_available_orders()  # 獲取所有尚未被接單的訂單
    return render_template("rider_orders.html", orders=available_orders)

@app.route("/rider/accept_order/<int:order_id>", methods=["POST"])
@login_required
def rider_accept_order(order_id):
    rider_id = session.get('rider_id')
    if accept_order(order_id, rider_id):
        flash("成功接單！")
    else:
        flash("接單失敗！")
    return redirect(url_for('rider_orders'))  # 接單後回到接單頁面

# 訂單取餐
@app.route("/rider/pickup_order/<int:order_id>", methods=["POST"])
@login_required
def rider_pickup_order(order_id):
    rider_id = session.get('rider_id')
    if pickup_order(order_id, rider_id):
        flash("已取餐，請前往送達！")
    else:
        flash("操作失敗！")
    return redirect(url_for('rider_dashboard'))

# 訂單送達
@app.route("/rider/complete_order/<int:order_id>", methods=["POST"])
@login_required
def rider_complete_order(order_id):
    rider_id = session.get('rider_id')
    if complete_order(order_id, rider_id):
        flash("訂單已完成！")
    else:
        flash("完成訂單失敗！")
    return redirect(url_for('rider_dashboard'))

@app.route("/rider/logout")
@login_required
def rider_logout():
    session.pop('rider_id', None)  # 清除 session 中的 rider_id
    flash("已成功登出")
    return redirect(url_for('rider_login'))

if __name__ == "__main__":
    app.run(debug=True)
